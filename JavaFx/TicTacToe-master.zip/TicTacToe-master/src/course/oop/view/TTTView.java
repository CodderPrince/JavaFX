package course.oop.view;

import javafx.scene.Parent;
import javafx.scene.Scene;

public interface TTTView {
    Parent getRoot();
}
