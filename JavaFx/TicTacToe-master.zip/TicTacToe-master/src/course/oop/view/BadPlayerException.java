package course.oop.view;

public class BadPlayerException extends Exception {
}
