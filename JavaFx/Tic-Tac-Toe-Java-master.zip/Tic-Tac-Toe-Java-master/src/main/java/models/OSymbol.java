package models;

public class OSymbol extends Symbol {
    public OSymbol() {
        super("O");
    }

    @Override
    public String toString() {
        return "O";
    }
}
