package models;

public class XSymbol extends Symbol {
    public XSymbol() {
        super("X");
    }

    @Override
    public String toString() {
        return "X";
    }

}
