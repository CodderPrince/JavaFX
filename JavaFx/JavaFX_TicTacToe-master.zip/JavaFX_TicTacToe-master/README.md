# javaFX_tic_tac_toe
This is a basic mini project on TicTacToe Game designed using JavaFX.

This is a easy project to start with javaFX GUI programming.

In this game, currently only Player vs Player mode is available.
However anyone interested person can implement Player vs Computer mode also.

IDE used : IntelliJ IDEA Community Edition

Thanks for reading this and Enjoy Coding ♥!!!!!
